package Login;


import java.io.IOException;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Infrastructure.LoadProperties;
import Infrastructure.Readfile;

import io.github.bonigarcia.wdm.WebDriverManager;


public class Program8_1 {

	static WebDriver driver=null;
	
	public static void Configuration() {
		
		WebDriverManager.chromedriver().clearDriverCache().setup();
		driver = new ChromeDriver();
	}
	
	public static void Login() throws IOException {

		String Sheetpath = "/home/darshan.joshi/eclipse-workspace/Assignment2/src/Exels/login.xls" ; 
		String Sheetname = "login" ;
		
		int xlcount = Infrastructure.Readfile.RowCount(Sheetpath,Sheetname);		
		
		
		Infrastructure.LoadProperties.getproperties("/home/darshan.joshi/eclipse-workspace/Demo-Maven/src/test/resources/login.properties");
		
		//Infrastructure.Readfile.getExeldetails(Infrastructure.Readfile.Sheetpath,Infrastructure.Readfile.Sheetname);
		
		driver.get("https://ops-qa.4onprintshop.com/admin/index.php");
		driver.manage().window().maximize();
		
		for(int i =1 ; i<=xlcount; i++) {	
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("username"))).sendKeys(Readfile.getExeldetails(i,Sheetpath,Sheetname,"username"));
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("password"))).sendKeys(Readfile.getExeldetails(i,Sheetpath,Sheetname,"password"));
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("loginbutton"))).click();
		}
	}
	
	
	
	
	public static void AddCustomer() throws IOException, InterruptedException {
		
		String Sheetpath = "/home/darshan.joshi/eclipse-workspace/Assignment2/src/Exels/add_customer.xls" ; 
		String Sheetname = "register" ;
		Infrastructure.LoadProperties.getproperties("/home/darshan.joshi/eclipse-workspace/Demo-Maven/src/test/resources/register.properties");

		driver.get("https://ops-qa.4onprintshop.com/admin/user_listing.php");	
		int xlcount = Infrastructure.Readfile.RowCount(Sheetpath,Sheetname);
		driver.findElement(By.xpath(LoadProperties.obj.getProperty("addbutton"))).click();
		Register(xlcount,Sheetpath,Sheetname);
	
	}
	
	public static void Register(int xlcount,String Sheetpath,String Sheetname) throws InterruptedException, IOException {
		
		
		
		for(int i =1 ; i<=xlcount; i++) { 
			
		driver.findElement(By.xpath(LoadProperties.obj.getProperty("firstname"))).sendKeys(Readfile.getExeldetails(i,Sheetpath,Sheetname,"firstname"));
		driver.findElement(By.xpath(LoadProperties.obj.getProperty("lastname"))).sendKeys(Readfile.getExeldetails(i ,Sheetpath,Sheetname,"lastname"));
		
		
		driver.findElement(By.xpath(LoadProperties.obj.getProperty("email"))).sendKeys("j@radixweb.com");
		driver.findElement(By.xpath(LoadProperties.obj.getProperty("password"))).sendKeys(Readfile.getExeldetails(i,Sheetpath,Sheetname,"password"));
		driver.findElement(By.xpath(LoadProperties.obj.getProperty("phonenumber"))).sendKeys(Readfile.getExeldetails(i,Sheetpath,Sheetname,"phonenumber"));
		
		driver.findElement(By.xpath(LoadProperties.obj.getProperty("salesagent"))).click();
		driver.findElement(By.xpath(LoadProperties.obj.getProperty("usergroup"))).click();
		
		driver.findElement(By.xpath(LoadProperties.obj.getProperty("Username"))).sendKeys(Readfile.getExeldetails(i,Sheetpath,Sheetname,"Username"));
		driver.findElement(By.xpath(LoadProperties.obj.getProperty("seconderyemail"))).sendKeys(Readfile.getExeldetails(i,Sheetpath,Sheetname,"seconderyemail"));
		
		
		driver.findElement(By.xpath(LoadProperties.obj.getProperty("countrybutton"))).click();
		driver.findElement(By.xpath(LoadProperties.obj.getProperty("countryindia"))).click();
		
		Thread.sleep(1000);
		
		driver.findElement(By.xpath(LoadProperties.obj.getProperty("statebutton"))).click();
		driver.findElement(By.xpath(LoadProperties.obj.getProperty("stategujarat"))).click();
		
		driver.findElement(By.xpath(LoadProperties.obj.getProperty("saveNbackbutton"))).click();
		
		}
		
		driver.get("https://ops-qa.4onprintshop.com/admin/user_listing.php");
		
	}

		
	public static void main(String[] args) throws IOException, InterruptedException {
			
			Configuration();
			Login();
			Thread.sleep(1000);
			AddCustomer();
			driver.close();


		}

	}