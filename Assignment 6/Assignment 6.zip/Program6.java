package Login;


import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxDriverService;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.GeckoDriverService;

import io.github.bonigarcia.wdm.WebDriverManager;


public class Program6 {
	
	public static FirefoxDriver getFirefoxDriver() {
		FirefoxProfile fp = new FirefoxProfile();
		fp.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/pdf, application/vnd.ms-excel, application/zip, multipart/x-zip, application/x-compressed, application/x-zip-compressed ");
		fp.setPreference("browser.download.manager.showWhenStarting", false);
		fp.setPreference("pdfjs.disabled", true);
        FirefoxOptions options = new FirefoxOptions();
        options.setProfile(fp);
        String osName = System.getProperty("os.name");
        String profileRoot = osName.contains("Linux") && new File("/snap/firefox").exists()? createProfileRootInUserHome(): null;
        return profileRoot != null? new FirefoxDriver(createGeckoDriverService(profileRoot), options): new FirefoxDriver(options);
    }
 
    private static String createProfileRootInUserHome() {
        String userHome = System.getProperty("user.home");
        File profileRoot = new File(userHome, "snap/firefox/common/.firefox-profile-root");
        if (!profileRoot.exists()) {
            if (!profileRoot.mkdirs()) {
                return null;
            }
        }
        return profileRoot.getAbsolutePath();
    }
 
    private static GeckoDriverService createGeckoDriverService(final String tempProfileDir) {
        return new GeckoDriverService.Builder() {
            @Override
            protected List<String> createArgs() {
                List<String> args = new ArrayList<>(super.createArgs());
                args.add(String.format("--profile-root=%s", tempProfileDir));
                return args;
            }
        }.build();
    }
	
	public static void main(String[] args) {
		
		
		 String s = "Chrome";
		
		if(s !=null) {
		ChromeDriver driver = new ChromeDriver();

		String url = "https://ops-qa.4onprintshop.com/admin/index.php";

		driver.get(url);
		driver.manage().window().maximize();
		driver.close();
		
		
		WebDriverManager.firefoxdriver().clearDriverCache().setup();
		
        FirefoxProfile profile = new FirefoxProfile();
        FirefoxOptions options = new FirefoxOptions();
        options.setProfile(profile);
		
		FirefoxDriver driver1 = getFirefoxDriver();

		String url1 = "https://ops-qa.4onprintshop.com/admin/index.php";
		
		driver1.get(url1);
		driver1.manage().window().maximize();
		driver1.close();
		
		System.out.println("Program Run Successfully and closed");
	}
}
   }