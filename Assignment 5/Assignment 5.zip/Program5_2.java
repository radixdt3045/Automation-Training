package PracticeAssignment;



import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class Program5_2 {
    public static void main(String[] args) throws IOException {
      
    	FileOutputStream out = new FileOutputStream("/home/darshan.joshi/eclipse-workspace/Assignment2/src/Exels/Testcase.xls");
    	
		@SuppressWarnings("resource")
		HSSFWorkbook workbook = new HSSFWorkbook();
        
        HSSFSheet sheet1 = workbook.createSheet();

        String[][] testData = {
            { "Test Case ID", "Description", "Result" },
            { "TC001", "Verify login functionality", "Pass" },
            { "TC002", "Verify registration process", "Fail" },
            { "TC003", "Verify search feature", "Pass" },
            { "TC004", "Verify logout functionality", "Pass" }};

      
            for (int i = 0; i < testData.length; i++) {
                Row row = sheet1.createRow(i);
                for (int j = 0; j < testData[i].length; j++) {
                    Cell cell = row.createCell(j);
                    cell.setCellValue(testData[i][j]);
                }
            }
            workbook.write(out);
            out.close();
            System.out.println("Test cases written successfully");
        }
    }
