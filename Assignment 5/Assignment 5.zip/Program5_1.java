package PracticeAssignment;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class Program5_1 {

		public static void main(String[] args) throws IOException
		

		{
			
			File file = new File("/home/darshan.joshi/eclipse-workspace/Assignment2/src/Exels/ProductList.xls");
			
			FileInputStream FIS = new FileInputStream(file);
			
			@SuppressWarnings("resource")
			HSSFWorkbook wb = new HSSFWorkbook(FIS);
			
			HSSFSheet sheet2 = wb.getSheet("Sheet1");
		
			int rowCount = sheet2.getLastRowNum()-sheet2.getFirstRowNum();
			
	        for(int i=1; i<= rowCount; i++){
	            
	            int cellcount = sheet2.getRow(i).getLastCellNum();
	            
	            System.out.println("\nRow "+ i +" data is :");
	            
	            for(int j=0;j<cellcount;j++){
	                System.out.print(sheet2.getRow(i).getCell(j).getStringCellValue() + ", ");
	            }
	            System.out.println();
	        }
	        wb.close();
	        FIS.close();
		}
		
}